package image.faceanalyze;

/**
 * Auto-generated: 2018-12-25 15:6:3
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class QualityCheckResult {

    private String failureReason;
    private boolean pass;
    public void setFailureReason(String failureReason) {
         this.failureReason = failureReason;
     }
     public String getFailureReason() {
         return failureReason;
     }

    public void setPass(boolean pass) {
         this.pass = pass;
     }
     public boolean getPass() {
         return pass;
     }

}