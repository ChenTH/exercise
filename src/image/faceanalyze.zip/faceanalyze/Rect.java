package image.faceanalyze;

/**
 * Auto-generated: 2018-12-25 15:6:3
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Rect {

    private int heightPixels;
    private int leftPixels;
    private int topPixels;
    private int widthPixels;
    public void setHeightPixels(int heightPixels) {
         this.heightPixels = heightPixels;
     }
     public int getHeightPixels() {
         return heightPixels;
     }

    public void setLeftPixels(int leftPixels) {
         this.leftPixels = leftPixels;
     }
     public int getLeftPixels() {
         return leftPixels;
     }

    public void setTopPixels(int topPixels) {
         this.topPixels = topPixels;
     }
     public int getTopPixels() {
         return topPixels;
     }

    public void setWidthPixels(int widthPixels) {
         this.widthPixels = widthPixels;
     }
     public int getWidthPixels() {
         return widthPixels;
     }

}