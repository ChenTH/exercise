package image.faceanalyze;

/**
 * Auto-generated: 2018-12-25 15:6:3
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Pose {

    private double pitch;
    private double roll;
    private double yaw;
    public void setPitch(double pitch) {
         this.pitch = pitch;
     }
     public double getPitch() {
         return pitch;
     }

    public void setRoll(double roll) {
         this.roll = roll;
     }
     public double getRoll() {
         return roll;
     }

    public void setYaw(double yaw) {
         this.yaw = yaw;
     }
     public double getYaw() {
         return yaw;
     }

}