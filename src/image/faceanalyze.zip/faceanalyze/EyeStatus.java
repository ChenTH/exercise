package image.faceanalyze;

/**
 * Auto-generated: 2018-12-25 15:6:3
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class EyeStatus {

    private String leftEye;
    private String rightEye;
    public void setLeftEye(String leftEye) {
         this.leftEye = leftEye;
     }
     public String getLeftEye() {
         return leftEye;
     }

    public void setRightEye(String rightEye) {
         this.rightEye = rightEye;
     }
     public String getRightEye() {
         return rightEye;
     }

}