package image.faceanalyze;

/**
 * Auto-generated: 2018-12-25 15:6:3
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Locator {

    private Rect rect;
    public void setRect(Rect rect) {
         this.rect = rect;
     }
     public Rect getRect() {
         return rect;
     }

}