package image.faceanalyze;

/**
 * Auto-generated: 2018-12-25 15:6:3
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Faces {

    private Attributes attributes;
    private Locator locator;
    private QualityCheckResult qualityCheckResult;
    public void setAttributes(Attributes attributes) {
         this.attributes = attributes;
     }
     public Attributes getAttributes() {
         return attributes;
     }

    public void setLocator(Locator locator) {
         this.locator = locator;
     }
     public Locator getLocator() {
         return locator;
     }

    public void setQualityCheckResult(QualityCheckResult qualityCheckResult) {
         this.qualityCheckResult = qualityCheckResult;
     }
     public QualityCheckResult getQualityCheckResult() {
         return qualityCheckResult;
     }

}